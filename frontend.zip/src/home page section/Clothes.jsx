import React from 'react'

const Clothes = () => {
  return (
    <div>Clothes</div>
  )
}

export default Clothes