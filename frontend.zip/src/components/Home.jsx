import React from 'react'
import Hero from '../home page section/Hero'
import Content from '../home page section/Content'
const Home = () => {
  return (
    <div>
      <Hero/>
      <br/> <br/>
      <Content/>
      <br/> <br/>
    </div>
  )
}

export default Home