import React from "react";
import "../App.css";
import CountUps from "./CountUps";
const About = () => {
  return (
    <div>
      <div className="contact">
        HOME / <span style={{ color: "red" }}> ABOUT </span>{" "}
      </div>
      <br />
      <br />
      <div className="aboutsec2">
        <div className="aboutmini1"></div>
        <div className="aboutmini2" style={{ textAlign: "left" }}>
     
          <i>
            <p>
              Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officia
              ipsam fugiat doloremque facilis molestias error recusandae,
              assumenda cupiditate omnis laudantium dolorem eaque deserunt
              quisquam temporibus debitis? Nihil ducimus omnis minus architecto
              deleniti vel, repellendus eos quos perspiciatis sunt dignissimos
              iusto sint maiores ratione iste delectus quasi a possimus
              quisquam, cum ipsa. Vero animi eum iusto saepe atque veniam
              quidem, itaque exercitationem. Officia eaque itaque veritatis
              inventore harum, in consequuntur nobis ut magnam nesciunt
              aspernatur. Distinctio doloribus quas expedita in quia fugiat id
              voluptas eum accusamus minus! Corrupti adipisci itaque eius
              aliquam nostrum quidem sapiente deleniti impedit. Nam sint
              voluptatum corrupti ipsam, impedit praesentium eius dicta aliquam
              voluptates eos provident illum molestiae inventore libero!
              Adipisci rem iste, illo facere laboriosam sint odit repellat fugit
              iure deserunt voluptates ut doloremque esse. Consequatur illum rem
              numquam quo tempora vitae consequuntur aut aliquam, deleniti
              soluta exercitationem magnam nobis, molestias placeat nisi
              aspernatur ducimus odio?
            </p>
          </i>
        </div>
      </div>
      <br /><br />
      <div className="aboutsec22">
        <div className="aboutmini11"></div>
        <div className="aboutmini22" style={{ textAlign: "left" }}>
     
          <i>
            <p>
              Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officia
              ipsam fugiat doloremque facilis molestias error recusandae,
              assumenda cupiditate omnis laudantium dolorem eaque deserunt
              quisquam temporibus debitis? Nihil ducimus omnis minus architecto
              deleniti vel, repellendus eos quos perspiciatis sunt dignissimos
              iusto sint maiores ratione iste delectus quasi a possimus
              quisquam, cum ipsa. Vero animi eum iusto saepe atque veniam
              quidem, itaque exercitationem. Officia eaque itaque veritatis
              inventore harum, in consequuntur nobis ut magnam nesciunt
              aspernatur. Distinctio doloribus quas expedita in quia fugiat id
              voluptas eum accusamus minus! Corrupti adipisci itaque eius
              aliquam nostrum quidem sapiente deleniti impedit. Nam sint
              voluptatum corrupti ipsam, impedit praesentium eius dicta aliquam
              voluptates eos provident illum molestiae inventore libero!
              Adipisci rem iste, illo facere laboriosam sint odit repellat fugit
              iure deserunt voluptates ut doloremque esse. Consequatur illum rem
              numquam quo tempora vitae consequuntur aut aliquam, deleniti
              soluta exercitationem magnam nobis, molestias placeat nisi
              aspernatur ducimus odio?
            </p>
          </i>
        </div>
      </div>
<br /><br />
      <div className="aboutsec222">
        <div className="aboutmini111"></div>
        <div className="aboutmini222" style={{ textAlign: "left" }}>
     
          <i>
            <p>
              Lorem, ipsum dolor sit amet consectetur adipisicing elit. Officia
              ipsam fugiat doloremque facilis molestias error recusandae,
              assumenda cupiditate omnis laudantium dolorem eaque deserunt
              quisquam temporibus debitis? Nihil ducimus omnis minus architecto
              deleniti vel, repellendus eos quos perspiciatis sunt dignissimos
              iusto sint maiores ratione iste delectus quasi a possimus
              quisquam, cum ipsa. Vero animi eum iusto saepe atque veniam
              quidem, itaque exercitationem. Officia eaque itaque veritatis
              inventore harum, in consequuntur nobis ut magnam nesciunt
              aspernatur. Distinctio doloribus quas expedita in quia fugiat id
              voluptas eum accusamus minus! Corrupti adipisci itaque eius
              aliquam nostrum quidem sapiente deleniti impedit. Nam sint
              voluptatum corrupti ipsam, impedit praesentium eius dicta aliquam
              voluptates eos provident illum molestiae inventore libero!
              Adipisci rem iste, illo facere laboriosam sint odit repellat fugit
              iure deserunt voluptates ut doloremque esse. Consequatur illum rem
              numquam quo tempora vitae consequuntur aut aliquam, deleniti
              soluta exercitationem magnam nobis, molestias placeat nisi
              aspernatur ducimus odio?
            </p>
          </i>
        </div>
      </div>
      <br/>
      <br/>
      <CountUps/>
      <br/>
    </div>
    
  );
};

export default About;